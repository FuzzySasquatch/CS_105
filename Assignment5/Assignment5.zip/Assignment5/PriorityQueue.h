#ifndef __PRIORITY_QUEUE_CPP_9F4861BC
#define __PRIORITY_QUEUE_CPP_9F4861BC

#include "LinkedList.h" /// need to include the parent class
using namespace std;

/* your class */
template<class T>
class PriorityQueue : public LinkedList<T> {
public:
	PriorityQueue<T>& operator =(const PriorityQueue<T>& list) {
		if (this == &list)
        	return *this;
        /* Cleans the original list for the next step */
    	LinkedList<T>::clean();
    	/* Starts at the other list's head and moves through it, methodically 
    	   pushing list's values onto this */
    	for (Node<T>* current = list.head; current; current = current->next)
        	push(current->value);
    	return *this;
	}

	PriorityQueue<T> operator +(const T v) const {
		/* Copies this list to a new list */
		PriorityQueue<T> newList;
		for (Node<T>* current = LinkedList<T>::head; current; current = current->next)
        	newList.push(current->value);
        /* Pushes on the new value */
		newList.push(v);
		return newList;
	}

	PriorityQueue<T> operator +(const PriorityQueue<T>& list) const {
		/* Copies this list to a new list */
	    PriorityQueue<T> newList;
	    if (LinkedList<T>::head) {
			for (Node<T>* current = LinkedList<T>::head; current; current = current->next)
	        	newList.push(current->value);
   		}
   		/* Adds new values to newList */
	    for (Node<T>* current = list.head; current; current = current->next)
        	newList.push(current->value);
	    return newList;
	}
	
	PriorityQueue operator - (const int v) const {
		if (!LinkedList<T>::head)
        	throw "Exception: subtraction from empty queue";
        /* Copies this list to a new list excluding the value to be subtracted */
		PriorityQueue<T> newList;
		for (Node<T>* current = LinkedList<T>::head; current; current = current->next) {
        	if (current->value != v)
        		newList.push(current->value);
		}
		return newList;
	}

	PriorityQueue operator -(const PriorityQueue& list) const {
		if (!LinkedList<T>::head)
        	throw "Exception: subtraction from empty queue";
        /* Create a new list object and copy old values to it */
		PriorityQueue<T> newList;
		for (Node<T>* current = LinkedList<T>::head; current; current = current->next)
	        		newList.push(current->value);
	    /* Subtract elements from list from newList */
		T v;
		for (Node<T>* subList = list.head; subList; subList = subList->next) {
        	v = subList->value;
        	newList = newList - v;
		}
		return newList;
	}

	void push(T value) {
		/* At least one node has been placed */
		if (LinkedList<T>::head && LinkedList<T>::tail) {
			Node<T>* newNode = new Node<T>(value);
			Node<T>* current = LinkedList<T>::head;
			Node<T>* previous;

			/* The new value is less than or equal to the first node */
			if (value <= peek()) {

				newNode->next = LinkedList<T>::head;
				LinkedList<T>::head = newNode;

			/* The new node is greater than at least the first node */
			} else {
				while (current->next && (value > current->value)) {
					previous = current;
					current = current->next;
				}

				/* The new node is greater than the last node */
				if (!current->next && value > current->value) {
					LinkedList<T>::tail->next = newNode;
					LinkedList<T>::tail = newNode;

				/* The new node is less than or equal to the last node 
				   and greater than the first node */
				} else {
					newNode->next = current;
					previous->next = newNode;
				}
			}	

		/* Creates the first node and sets head and tail equal to it */	
		} else {
			Node<T>* firstNode = new Node<T>(value);
			LinkedList<T>::tail = firstNode;
			LinkedList<T>::head = firstNode;
		}
	}
	T peek() {
		if (LinkedList<T>::head)
			return LinkedList<T>::head->value;
		else
        	throw "Exception: tried to peek at an empty queue";
		return 0;
	}
};

#endif